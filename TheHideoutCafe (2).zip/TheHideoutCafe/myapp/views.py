from datetime import datetime
from django.contrib.humanize.templatetags.humanize import intcomma
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from .models import ThucDon, DonHang, ChiTietDonHang, GioHang, ThongBao, DanhGia, NguoiDung, BanAn, DatBan
from django.contrib import messages
from django.utils.timezone import now
from decimal import Decimal
import logging
import pytz

# Thiết lập logging
logger = logging.getLogger(__name__)

# View điều hướng dựa trên vai trò
@login_required
def redirect_based_on_role(request):
    if request.user.vai_tro == 'quan_ly':
        return redirect('myapp:menu_management')
    elif request.user.vai_tro == 'nhan_vien':
        return redirect('myapp:menu_nhanvien')
    elif request.user.vai_tro == 'khach_hang':
        return redirect('myapp:menu_khachhang')
    else:
        return redirect('logout')

# Views cho quản lý
@login_required
def menu_management(request):
    if request.user.vai_tro != 'quan_ly':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý.")
        return redirect('myapp:redirect_based_on_role')

    thuc_don = ThucDon.objects.all()
    return render(request, 'menu_quanly.html', {'thuc_don': thuc_don})

@login_required
def add_menu_item(request):
    if request.user.vai_tro != 'quan_ly':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ten_mon = request.POST.get('ten_mon')
        gia_tien = request.POST.get('gia_tien')
        hinh_anh = request.FILES.get('hinh_anh')

        try:
            mon = ThucDon(ten_mon=ten_mon, gia_tien=gia_tien, hinh_anh=hinh_anh)
            mon.save()
            messages.success(request, "Thêm món thành công!")
        except Exception as e:
            messages.error(request, f"Lỗi khi thêm món: {str(e)}")

        return redirect('myapp:menu_management')
    return redirect('myapp:menu_management')

@login_required
def edit_menu_item(request):
    if request.user.vai_tro != 'quan_ly':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        mon = get_object_or_404(ThucDon, ma_mon=ma_mon)

        mon.ten_mon = request.POST.get('ten_mon')
        mon.gia_tien = request.POST.get('gia_tien')
        if request.FILES.get('hinh_anh'):
            mon.hinh_anh = request.FILES.get('hinh_anh')

        try:
            mon.save()
            messages.success(request, "Sửa món thành công!")
        except Exception as e:
            messages.error(request, f"Lỗi khi sửa món: {str(e)}")

        return redirect('myapp:menu_management')
    return redirect('myapp:menu_management')

@login_required
def toggle_menu_item_visibility(request):
    if request.user.vai_tro != 'quan_ly':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        da_an = request.POST.get('da_an') == 'true'
        mon = get_object_or_404(ThucDon, ma_mon=ma_mon)

        try:
            mon.da_an = da_an
            mon.save()
            action = "Ẩn" if da_an else "Hiện"
            messages.success(request, f"{action} món thành công!")
        except Exception as e:
            messages.error(request, f"Lỗi khi {action.lower()} món: {str(e)}")

    return redirect('myapp:menu_management')

@login_required
def order_list(request):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request,
                       "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    don_hang_list = DonHang.objects.all().order_by('-ngay_tao')
    thuc_don = ThucDon.objects.all()
    loai_don_hang_choices = DonHang.LOAI_DON_HANG
    trang_thai_choices = DonHang.TRANG_THAI
    thanh_toan_choices = DonHang.THANH_TOAN

    context = {
        'don_hang_list': don_hang_list,
        'thuc_don': thuc_don,
        'loai_don_hang_choices': loai_don_hang_choices,
        'trang_thai_choices': trang_thai_choices,
        'thanh_toan_choices': thanh_toan_choices,
        'intcomma': intcomma,
    }
    return render(request, 'quanlydonhang_ql.html', context)

@login_required
def create_order(request):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request,
                       "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == 'POST':
        try:
            ten_khach_hang = request.POST.get('ten_khach_hang') or request.user.ho_ten or request.user.username
            loai_don_hang = request.POST.get('loai_don_hang')
            trang_thai = request.POST.get('trang_thai')
            thanh_toan = request.POST.get('thanh_toan')
            dia_chi = request.POST.get('dia_chi', '')
            ngay_tao = request.POST.get('ngay_tao')
            so_dien_thoai = request.POST.get('so_dien_thoai', '')
            thoi_gian_dat = request.POST.get('thoi_gian_dat', '')
            phi_ship = Decimal(request.POST.get('phi_ship', '0'))

            total_money = Decimal(0)
            order_details = []
            thuc_don = ThucDon.objects.all()

            for mon in thuc_don:
                checkbox = request.POST.get(f'mon_an_{mon.ma_mon}')
                quantity = request.POST.get(f'so_luong_{mon.ma_mon}', '0')
                if checkbox and int(quantity) > 0:
                    quantity = int(quantity)
                    subtotal = mon.gia_tien * quantity
                    total_money += subtotal
                    order_details.append({
                        'mon_an': mon,
                        'so_luong': quantity,
                        'gia_tien': mon.gia_tien,
                    })

            if total_money == 0:
                messages.error(request, 'Vui lòng chọn ít nhất một món ăn với số lượng lớn hơn 0.')
                return redirect('myapp:order_list')

            if not NguoiDung.objects.filter(pk=request.user.pk).exists():
                logger.error(f"User with ID {request.user.pk} does not exist")
                messages.error(request, f'Người dùng với ID {request.user.pk} không tồn tại.')
                return redirect('myapp:order_list')

            don_hang = DonHang.objects.create(
                nguoi_dung=request.user,
                loai_don_hang=loai_don_hang,
                trang_thai=trang_thai,
                thanh_toan=thanh_toan,
                dia_chi=dia_chi if loai_don_hang == 'truc_tuyen' else '',
                so_dien_thoai=so_dien_thoai if loai_don_hang in ['truc_tuyen', 'mang_di'] else (
                    request.user.so_dien_thoai if request.user.so_dien_thoai else ''),
                thoi_gian_dat=thoi_gian_dat if loai_don_hang in ['tai_quan', 'mang_di'] else None,
                phi_ship=phi_ship,
                tong_tien=total_money,
                ngay_tao=now() if not ngay_tao else ngay_tao
            )

            for detail in order_details:
                if not ThucDon.objects.filter(pk=detail['mon_an'].pk).exists():
                    logger.error(f"ThucDon with ID {detail['mon_an'].pk} does not exist")
                    messages.error(request, f'Món ăn với ID {detail["mon_an"].pk} không tồn tại.')
                    don_hang.delete()
                    return redirect('myapp:order_list')
                ChiTietDonHang.objects.create(
                    don_hang=don_hang,
                    mon_an=detail['mon_an'],
                    so_luong=detail['so_luong'],
                    gia_tien=detail['gia_tien'],
                )

            quan_ly_nhan_vien = NguoiDung.objects.filter(vai_tro__in=['quan_ly', 'nhan_vien']).exclude(
                ma_nguoi_dung=request.user.ma_nguoi_dung)
            for nguoi_nhan in quan_ly_nhan_vien:
                if not NguoiDung.objects.filter(pk=nguoi_nhan.pk).exists():
                    logger.warning(f"Skipping ThongBao for nguoi_nhan ID {nguoi_nhan.pk}: Does not exist")
                    continue
                ThongBao.objects.create(
                    don_hang=don_hang,
                    nguoi_nhan=nguoi_nhan,
                    noi_dung=f"Có đơn hàng mới #{don_hang.ma_don_hang} từ {request.user.username}. Loại đơn: {don_hang.get_loai_don_hang_display()}."
                )

            messages.success(request, f'Đơn hàng {don_hang.ma_don_hang} đã được tạo thành công.')
            return redirect('myapp:order_list')

        except Exception as e:
            logger.error(f"Error in create_order: {str(e)}", exc_info=True)
            messages.error(request, f'Có lỗi xảy ra: {str(e)}')
            return redirect('myapp:order_list')

    return redirect('myapp:order_list')

@login_required
def update_order_status(request):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == 'POST':
        ma_don_hang = request.POST.get('ma_don_hang')
        trang_thai = request.POST.get('trang_thai')

        try:
            don_hang = get_object_or_404(DonHang, ma_don_hang=ma_don_hang)
            if trang_thai in dict(DonHang.TRANG_THAI).keys():
                old_status = don_hang.trang_thai
                don_hang.trang_thai = trang_thai
                don_hang.save()
                logger.info(f"Updated order #{ma_don_hang} from status '{old_status}' to '{trang_thai}'")

                # Gửi thông báo cho khách hàng khi trạng thái đơn hàng thay đổi
                if old_status != trang_thai:
                    if not don_hang.nguoi_dung:
                        logger.error(f"Order #{ma_don_hang} has no associated user (nguoi_dung is None). Cannot send notification.")
                    elif don_hang.nguoi_dung.vai_tro != 'khach_hang':
                        logger.info(f"Order #{ma_don_hang} belongs to {don_hang.nguoi_dung.vai_tro} ({don_hang.nguoi_dung.username}), not a customer. Skipping notification.")
                    else:
                        try:
                            ThongBao.objects.create(
                                don_hang=don_hang,
                                nguoi_nhan=don_hang.nguoi_dung,
                                noi_dung=f"Đơn hàng #{don_hang.ma_don_hang} của bạn đã thay đổi trạng thái thành '{don_hang.get_trang_thai_display()}'."
                            )
                            logger.info(f"Notification sent to user {don_hang.nguoi_dung.username} for order #{ma_don_hang}")
                        except Exception as e:
                            logger.error(f"Failed to send notification for order #{ma_don_hang}: {str(e)}")

                messages.success(request, 'Cập nhật trạng thái thành công!')
            else:
                messages.error(request, 'Trạng thái không hợp lệ!')
                logger.warning(f"Invalid status '{trang_thai}' for order #{ma_don_hang}")
        except Exception as e:
            messages.error(request, f'Lỗi khi cập nhật trạng thái: {str(e)}')
            logger.error(f"Error updating status for order #{ma_don_hang}: {str(e)}")

        return redirect('myapp:order_list')

    return redirect('myapp:order_list')

@login_required
def manage_bookings(request):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request,
                       "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    dat_ban_list = DatBan.objects.all().order_by('-thoi_gian_dat')
    context = {
        'dat_ban_list': dat_ban_list,
    }
    return render(request, 'manage_bookings.html', context)

@login_required
def confirm_booking(request, ma_dat_ban):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request,
                       "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == 'POST':
        try:
            dat_ban = get_object_or_404(DatBan, ma_dat_ban=ma_dat_ban)
            if dat_ban.trang_thai != 'cho_xac_nhan':
                messages.error(request, "Chỉ có thể xác nhận đặt bàn ở trạng thái 'Chờ Xác Nhận'.")
                return redirect('myapp:manage_bookings')

            dat_ban.trang_thai = 'da_xac_nhan'
            dat_ban.ban_an.trang_thai = 'co_nguoi'
            dat_ban.ban_an.save()
            dat_ban.save()
            messages.success(request, f"Đã xác nhận đặt bàn #{ma_dat_ban}.")
        except Exception as e:
            logger.error(f"Error in confirm_booking: {str(e)}", exc_info=True)
            messages.error(request, f"Lỗi khi xác nhận đặt bàn: {str(e)}")

    return redirect('myapp:manage_bookings')

@login_required
def cancel_booking(request, ma_dat_ban):
    if request.user.vai_tro not in ['quan_ly', 'nhan_vien']:
        messages.error(request,
                       "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản quản lý hoặc nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == 'POST':
        try:
            dat_ban = get_object_or_404(DatBan, ma_dat_ban=ma_dat_ban)
            if dat_ban.trang_thai != 'cho_xac_nhan':
                messages.error(request, "Chỉ có thể hủy đặt bàn ở trạng thái 'Chờ Xác Nhận'.")
                return redirect('myapp:manage_bookings')

            dat_ban.trang_thai = 'da_huy'
            dat_ban.save()
            messages.success(request, f"Đã hủy đặt bàn #{ma_dat_ban}.")
        except Exception as e:
            logger.error(f"Error in cancel_booking: {str(e)}", exc_info=True)
            messages.error(request, f"Lỗi khi hủy đặt bàn: {str(e)}")

    return redirect('myapp:manage_bookings')

# Views cho nhân viên
@login_required
def menu_nhanvien(request):
    if request.user.vai_tro != 'nhan_vien':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    thuc_don = ThucDon.objects.all()
    return render(request, 'menu_nhanvien.html', {'thuc_don': thuc_don})

@login_required
def edit_menu_item_nhanvien(request):
    if request.user.vai_tro != 'nhan_vien':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        mon = get_object_or_404(ThucDon, ma_mon=ma_mon)

        mon.ten_mon = request.POST.get('ten_mon')
        mon.gia_tien = request.POST.get('gia_tien')
        if request.FILES.get('hinh_anh'):
            mon.hinh_anh = request.FILES.get('hinh_anh')

        try:
            mon.save()
            messages.success(request, "Sửa món thành công!")
        except Exception as e:
            messages.error(request, f"Lỗi khi sửa món: {str(e)}")

        return redirect('myapp:menu_nhanvien')
    return redirect('myapp:menu_nhanvien')

@login_required
def toggle_menu_item_visibility_nhanvien(request):
    if request.user.vai_tro != 'nhan_vien':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản nhân viên.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        da_an = request.POST.get('da_an') == 'true'
        mon = get_object_or_404(ThucDon, ma_mon=ma_mon)

        try:
            mon.da_an = da_an
            mon.save()
            action = "Ẩn" if da_an else "Hiện"
            messages.success(request, f"{action} món thành công!")
        except Exception as e:
            messages.error(request, f"Lỗi khi {action.lower()} món: {str(e)}")

    return redirect('myapp:menu_nhanvien')

# Views cho khách hàng
@login_required
def menu_khachhang(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    thuc_don = ThucDon.objects.filter(da_an=False)
    gio_hang = GioHang.objects.filter(nguoi_dung=request.user)
    context = {
        'thuc_don': thuc_don,
        'gio_hang': gio_hang,
        'tong_mon_gio_hang': sum(item.so_luong for item in gio_hang),
    }
    return render(request, 'menu_khachhang.html', context)

@login_required
def add_to_cart(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        so_luong = int(request.POST.get('so_luong', 1))
        try:
            mon_an = ThucDon.objects.get(ma_mon=ma_mon)
            gio_hang, created = GioHang.objects.get_or_create(
                nguoi_dung=request.user,
                mon_an=mon_an,
                defaults={'so_luong': so_luong}
            )
            if not created:
                gio_hang.so_luong += so_luong
                gio_hang.save()

            # Kiểm tra xem có phải yêu cầu AJAX không
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success', 'message': f'Đã thêm {mon_an.ten_mon} vào giỏ hàng!'},
                                    ensure_ascii=False)
            else:
                # Yêu cầu thông thường: thêm thông báo và chuyển hướng
                messages.success(request, f'Đã thêm {mon_an.ten_mon} vào giỏ hàng!')
                return redirect('myapp:menu_khachhang')

        except ThucDon.DoesNotExist:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'error', 'message': 'Món ăn không tồn tại.'}, status=400,
                                    ensure_ascii=False)
            else:
                messages.error(request, 'Món ăn không tồn tại.')
                return redirect('myapp:menu_khachhang')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'status': 'error', 'message': 'Yêu cầu không hợp lệ.'}, status=400, ensure_ascii=False)
    else:
        messages.error(request, 'Yêu cầu không hợp lệ.')
        return redirect('myapp:menu_khachhang')

@login_required
def view_cart(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    gio_hang = GioHang.objects.filter(nguoi_dung=request.user)
    selected_items = request.POST.getlist('selected_items') if request.method == 'POST' else []
    if selected_items:
        selected_gio_hang = gio_hang.filter(mon_an__ma_mon__in=selected_items)
        tong_tien = sum(item.mon_an.gia_tien * item.so_luong for item in selected_gio_hang)
    else:
        tong_tien = sum(item.mon_an.gia_tien * item.so_luong for item in gio_hang)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        gio_hang_data = [
            {
                'mon_an': {
                    'ma_mon': item.mon_an.ma_mon,
                    'ten_mon': item.mon_an.ten_mon,
                    'gia_tien': float(item.mon_an.gia_tien),
                    'hinh_anh': item.mon_an.hinh_anh.url if item.mon_an.hinh_anh else None,
                },
                'so_luong': item.so_luong,
            }
            for item in gio_hang
        ]
        return JsonResponse({
            'gio_hang': gio_hang_data,
            'tong_tien': float(tong_tien),
        })

    context = {
        'gio_hang': gio_hang,
        'tong_tien': tong_tien,
        'selected_items': selected_items,
    }
    return render(request, 'view_cart.html', context)

@login_required
def update_cart(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == "POST":
        ma_mon = request.POST.get('ma_mon')
        action = request.POST.get('action')
        try:
            gio_hang = GioHang.objects.get(nguoi_dung=request.user, mon_an__ma_mon=ma_mon)
            if action == 'increase':
                gio_hang.so_luong += 1
                gio_hang.save()
            elif action == 'decrease':
                gio_hang.so_luong -= 1
                if gio_hang.so_luong <= 0:
                    gio_hang.delete()
                    return JsonResponse({'status': 'deleted', 'message': ''})
                gio_hang.save()
            all_gio_hang = GioHang.objects.filter(nguoi_dung=request.user)
            tong_tien = sum(item.mon_an.gia_tien * item.so_luong for item in all_gio_hang)
            return JsonResponse({
                'status': 'success',
                'so_luong': gio_hang.so_luong,
                'tong_tien': float(tong_tien),
                'message': ''
            })
        except GioHang.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Món không tồn tại.'}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Yêu cầu không hợp lệ.'}, status=400)

@login_required
def place_order(request):
    # Kiểm tra trạng thái đăng nhập
    if not request.user.is_authenticated:
        logger.warning("User is not authenticated")
        return HttpResponse("Vui lòng đăng nhập để tiếp tục.", status=401)

    # Kiểm tra vai trò
    logger.info(
        f"User: {request.user.username}, Vai tro: {request.user.vai_tro if hasattr(request.user, 'vai_tro') else 'Not set'}")
    if not hasattr(request.user, 'vai_tro') or request.user.vai_tro != 'khach_hang':
        logger.warning(
            f"User {request.user.username} does not have role 'khach_hang'. Current role: {request.user.vai_tro if hasattr(request.user, 'vai_tro') else 'Not set'}")
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Yêu cầu không hợp lệ.'}, status=400)

    try:
        logger.info(f"Received place_order request from user {request.user.username}")
        selected_items = request.POST.getlist('selected_items')
        dia_chi = request.POST.get('dia_chi', '').strip()
        loai_don_hang = request.POST.get('loai_don_hang', 'truc_tuyen')
        so_ban = request.POST.get('so_ban', '').strip()
        so_dien_thoai = request.POST.get('so_dien_thoai', '').strip()
        thoi_gian_dat = request.POST.get('thoi_gian_dat', '')
        # Thêm phương thức thanh toán từ form
        thanh_toan_phuong_thuc = request.POST.get('phuong_thuc_thanh_toan', 'tien_mat')

        logger.debug(
            f"Selected items: {selected_items}, Loai don hang: {loai_don_hang}, Dia chi: {dia_chi}, So dien thoai: {so_dien_thoai}, Thoi gian dat: {thoi_gian_dat}")

        if not selected_items:
            return JsonResponse({'status': 'error', 'message': 'Vui lòng chọn ít nhất một món để đặt hàng.'})

        # Lấy thời gian hiện tại bằng timezone.now() và ép buộc múi giờ +07
        current_time = now()
        logger.info(f"Raw system time from now(): {current_time}, Timezone: {current_time.tzinfo}")
        # Ép buộc múi giờ +07
        tz = pytz.timezone('Asia/Ho_Chi_Minh')
        current_time = current_time.astimezone(tz)
        logger.info(f"Adjusted system time to +07: {current_time}, Timezone: {current_time.tzinfo}")
        current_hour = current_time.hour
        current_minute = current_time.minute
        current_time_in_minutes = current_hour * 60 + current_minute
        logger.info(f"Adjusted time in minutes: {current_time_in_minutes}")
        opening_time = 7 * 60 + 30  # 7h30
        closing_time = 22 * 60  # 22h

        if loai_don_hang in ['truc_tuyen', 'tai_quan']:
            if current_time_in_minutes < opening_time or current_time_in_minutes > closing_time:
                logger.warning(
                    f"Order rejected: Current time {current_time_in_minutes} is outside operating hours ({opening_time}-{closing_time})")
                return JsonResponse(
                    {'status': 'error', 'message': 'Quán chỉ nhận đơn Trực Tuyến và Tại Quán từ 7h30 đến 22h.'})

        if loai_don_hang == 'truc_tuyen':
            if not dia_chi or not any(city in dia_chi.lower() for city in ['đà nẵng', 'da nang']):
                return JsonResponse({'status': 'error', 'message': 'Chúng tôi chỉ giao hàng tại Đà Nẵng.'})
            if not so_dien_thoai:
                return JsonResponse({'status': 'error', 'message': 'Vui lòng nhập số điện thoại.'})
        elif loai_don_hang == 'tai_quan':
            if not so_ban:
                return JsonResponse({'status': 'error', 'message': 'Vui lòng chọn số bàn.'})
        elif loai_don_hang == 'mang_di':
            if not so_dien_thoai:
                return JsonResponse({'status': 'error', 'message': 'Vui lòng nhập số điện thoại.'})
            if not thoi_gian_dat:
                return JsonResponse({'status': 'error', 'message': 'Vui lòng chọn thời gian đến lấy.'})

        phi_ship = 25000 if loai_don_hang == 'truc_tuyen' else 0
        gio_hang_items = GioHang.objects.filter(nguoi_dung=request.user, mon_an__ma_mon__in=selected_items)
        if not gio_hang_items.exists():
            return JsonResponse({'status': 'error', 'message': 'Không tìm thấy món hàng nào trong giỏ.'})

        if not NguoiDung.objects.filter(pk=request.user.pk).exists():
            logger.error(f"User with ID {request.user.pk} does not exist")
            return JsonResponse({'status': 'error', 'message': 'Người dùng không tồn tại.'}, status=400)

        for item in gio_hang_items:
            if not ThucDon.objects.filter(pk=item.mon_an_id).exists():
                logger.error(f"ThucDon with ID {item.mon_an_id} does not exist for GioHang item")
                return JsonResponse({'status': 'error', 'message': f'Món ăn với ID {item.mon_an_id} không tồn tại.'},
                                    status=400)

        tong_tien = sum(item.mon_an.gia_tien * item.so_luong for item in gio_hang_items) + phi_ship

        # Xử lý thoi_gian_dat để tránh lỗi định dạng
        thoi_gian_dat_value = None
        if loai_don_hang in ['tai_quan', 'mang_di'] and thoi_gian_dat:
            try:
                thoi_gian_dat_value = datetime.strptime(thoi_gian_dat, '%Y-%m-%dT%H:%M')
                thoi_gian_dat_value = pytz.timezone('Asia/Ho_Chi_Minh').localize(thoi_gian_dat_value)
                logger.info(f"Parsed thoi_gian_dat: {thoi_gian_dat_value}")
            except ValueError as e:
                logger.error(f"Invalid thoi_gian_dat format: {thoi_gian_dat}, Error: {str(e)}")
                return JsonResponse({'status': 'error',
                                     'message': 'Thời gian đến lấy không hợp lệ. Vui lòng chọn thời gian theo định dạng YYYY-MM-DD HH:MM.'},
                                    status=400)

        # Xác định trạng thái thanh toán dựa trên phương thức
        if thanh_toan_phuong_thuc == 'chuyen_khoan':
            trang_thai_thanh_toan = 'da_thanh_toan'
        else:
            trang_thai_thanh_toan = 'chua_thanh_toan'

        don_hang = DonHang(
            nguoi_dung=request.user,
            loai_don_hang=loai_don_hang,
            trang_thai='da_xac_nhan',
            thanh_toan=trang_thai_thanh_toan,
            dia_chi=dia_chi if loai_don_hang == 'truc_tuyen' else '',
            so_dien_thoai=so_dien_thoai if loai_don_hang in ['truc_tuyen', 'mang_di'] else (
                request.user.so_dien_thoai if request.user.so_dien_thoai else ''),
            phi_ship=phi_ship,
            tong_tien=tong_tien,
            thoi_gian_dat=thoi_gian_dat_value,
            ngay_tao=now()
        )
        don_hang.save()
        logger.info(f"Created DonHang with ID: {don_hang.ma_don_hang}")

        for item in gio_hang_items:
            ChiTietDonHang.objects.create(
                don_hang=don_hang,
                mon_an=item.mon_an,
                so_luong=item.so_luong,
                gia_tien=item.mon_an.gia_tien
            )
            item.delete()

        quan_ly_nhan_vien = NguoiDung.objects.filter(vai_tro__in=['quan_ly', 'nhan_vien'])
        for nguoi_nhan in quan_ly_nhan_vien:
            if not NguoiDung.objects.filter(pk=nguoi_nhan.pk).exists():
                logger.warning(f"Skipping ThongBao for nguoi_nhan ID {nguoi_nhan.pk}: Does not exist")
                continue
            ThongBao.objects.create(
                don_hang=don_hang,
                nguoi_nhan=nguoi_nhan,
                noi_dung=f"Có đơn hàng mới #{don_hang.ma_don_hang} từ {request.user.username}. Loại đơn: {don_hang.get_loai_don_hang_display()} ({'Đã thanh toán' if trang_thai_thanh_toan == 'da_thanh_toan' else 'Chưa thanh toán'})."
            )

        return JsonResponse({'status': 'success', 'ma_don_hang': don_hang.ma_don_hang})

    except Exception as e:
        logger.error(f"Error in place_order: {str(e)}", exc_info=True)
        return JsonResponse({'status': 'error', 'message': f'Lỗi khi tạo đơn hàng: {str(e)}'}, status=500)

@login_required
def order_detail(request, ma_don_hang):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    don_hang = get_object_or_404(DonHang, ma_don_hang=ma_don_hang, nguoi_dung=request.user)
    chi_tiet_don_hang = ChiTietDonHang.objects.filter(don_hang=don_hang)

    # Log trạng thái đơn hàng để kiểm tra
    logger.info(f"Order {ma_don_hang} status: {don_hang.trang_thai}")

    context = {
        'don_hang': don_hang,
        'chi_tiet_don_hang': chi_tiet_don_hang,
    }
    return render(request, 'order_detail.html', context)

@login_required
def rate_order(request, ma_don_hang):
    logger.info(
        f"User {request.user.username} attempting to access rate_order for order {ma_don_hang}, Role: {request.user.vai_tro if hasattr(request.user, 'vai_tro') else 'Not set'}")

    if not hasattr(request.user, 'vai_tro') or request.user.vai_tro != 'khach_hang':
        logger.warning(f"User {request.user.username} does not have role 'khach_hang'. Redirecting to order_history.")
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:order_history')

    don_hang = get_object_or_404(DonHang, ma_don_hang=ma_don_hang, nguoi_dung=request.user)

    # Kiểm tra trạng thái đơn hàng
    if don_hang.trang_thai != 'hoan_thanh':
        messages.error(request, "Chỉ có thể đánh giá các đơn hàng đã hoàn thành.")
        return redirect('myapp:order_history')

    # Kiểm tra thời gian 10 ngày kể từ ngày tạo đơn hàng
    ngay_tao = don_hang.ngay_tao
    ngay_hien_tai = now()
    thoi_gian_da_qua = (ngay_hien_tai - ngay_tao).days

    # Lấy các đánh giá liên quan đến đơn hàng
    danh_gia_ban_dau = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=True).first()
    danh_gia_bo_sung = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=False).first()

    # Kiểm tra điều kiện để hiển thị nút đánh giá
    if not danh_gia_ban_dau and thoi_gian_da_qua > 10:
        messages.error(request, "Đã quá 10 ngày kể từ khi đơn hàng được tạo. Bạn không thể đánh giá đơn hàng này.")
        return redirect('myapp:order_history')
    if danh_gia_ban_dau and danh_gia_bo_sung:
        messages.error(request, "Bạn đã đánh giá bổ sung cho đơn hàng này. Không thể đánh giá thêm.")
        return redirect('myapp:order_history')

    if request.method == 'POST':
        so_sao = int(request.POST.get('so_sao', 0))
        nhan_xet = request.POST.get('nhan_xet', '').strip()
        hinh_anh = request.FILES.get('hinh_anh')

        if not (1 <= so_sao <= 5):
            messages.error(request, "Số sao phải từ 1 đến 5.")
            return redirect('myapp:rate_order', ma_don_hang=ma_don_hang)

        try:
            if danh_gia_ban_dau:  # Nếu đã có đánh giá ban đầu, đây là đánh giá bổ sung
                if danh_gia_bo_sung:  # Nếu đã có đánh giá bổ sung, không cho phép đánh giá thêm
                    messages.error(request, "Bạn đã đánh giá bổ sung cho đơn hàng này. Không thể đánh giá thêm.")
                    return redirect('myapp:order_history')
                # Tạo đánh giá bổ sung
                DanhGia.objects.create(
                    don_hang=don_hang,
                    so_sao=so_sao,
                    nhan_xet=nhan_xet,
                    hinh_anh=hinh_anh,
                    la_danh_gia_ban_dau=False,
                    ngay_danh_gia=now()
                )
                messages.success(request, "Gửi đánh giá bổ sung thành công!")
            else:  # Nếu chưa có đánh giá ban đầu
                if thoi_gian_da_qua > 10:
                    messages.error(request, "Đã quá 10 ngày kể từ khi đơn hàng được tạo. Bạn không thể đánh giá đơn hàng này.")
                    return redirect('myapp:order_history')
                # Tạo đánh giá ban đầu
                DanhGia.objects.create(
                    don_hang=don_hang,
                    so_sao=so_sao,
                    nhan_xet=nhan_xet,
                    hinh_anh=hinh_anh,
                    la_danh_gia_ban_dau=True,
                    ngay_danh_gia=now()
                )
                messages.success(request, "Cảm ơn bạn đã đánh giá đơn hàng!")
            return redirect('myapp:order_history')
        except Exception as e:
            logger.error(f"Error in rate_order while creating/updating DanhGia: {str(e)}")
            messages.error(request, f"Lỗi khi gửi đánh giá: {str(e)}")
            return redirect('myapp:rate_order', ma_don_hang=ma_don_hang)

    context = {
        'don_hang': don_hang,
        'danh_gia_ban_dau': danh_gia_ban_dau,
        'danh_gia_bo_sung': danh_gia_bo_sung,
        'thoi_gian_da_qua': thoi_gian_da_qua,
    }
    return render(request, 'rate_order.html', context)

@login_required
def order_history(request):
    logger.info(
        f"User {request.user.username} accessing order_history, Role: {request.user.vai_tro if hasattr(request.user, 'vai_tro') else 'Not set'}")

    if not hasattr(request.user, 'vai_tro') or request.user.vai_tro != 'khach_hang':
        logger.warning(
            f"User {request.user.username} does not have role 'khach_hang'. Redirecting to redirect_based_on_role.")
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    don_hang_list = DonHang.objects.filter(nguoi_dung=request.user).order_by('-ngay_tao')
    ngay_hien_tai = now()

    # Xử lý logic lọc đánh giá và tính thời gian đã qua cho từng đơn hàng
    don_hang_data = []
    for don_hang in don_hang_list:
        thoi_gian_da_qua = (ngay_hien_tai - don_hang.ngay_tao).days
        # Sử dụng filter() trực tiếp thay vì truy cập don_hang.danh_gia
        danh_gia_ban_dau = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=True).first()
        danh_gia_bo_sung = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=False).first()
        don_hang_data.append({
            'don_hang': don_hang,
            'thoi_gian_da_qua': thoi_gian_da_qua,
            'danh_gia_ban_dau': danh_gia_ban_dau,
            'danh_gia_bo_sung': danh_gia_bo_sung,
        })

    context = {'don_hang_data': don_hang_data}
    return render(request, 'order_history.html', context)

@login_required
def cancel_order(request, ma_don_hang):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    don_hang = get_object_or_404(DonHang, ma_don_hang=ma_don_hang, nguoi_dung=request.user)

    if request.method == 'POST':
        if don_hang.trang_thai != 'da_xac_nhan':
            messages.error(request, "Không thể hủy đơn hàng vì đã được xử lý.")
        else:
            don_hang.trang_thai = 'da_huy'
            don_hang.save()
            messages.success(request, f"Đã hủy đơn hàng #{ma_don_hang}.")
        return redirect('myapp:order_history')

    return redirect('myapp:order_detail', ma_don_hang=ma_don_hang)

@login_required
def reorder(request, ma_don_hang):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    don_hang = get_object_or_404(DonHang, ma_don_hang=ma_don_hang, nguoi_dung=request.user)
    chi_tiet_don_hang = ChiTietDonHang.objects.filter(don_hang=don_hang)

    for chi_tiet in chi_tiet_don_hang:
        mon_an = chi_tiet.mon_an
        if not mon_an.da_an:
            gio_hang, created = GioHang.objects.get_or_create(
                nguoi_dung=request.user,
                mon_an=mon_an,
                defaults={'so_luong': chi_tiet.so_luong}
            )
            if not created:
                gio_hang.so_luong += chi_tiet.so_luong
                gio_hang.save()

    messages.success(request, "Đã thêm các món từ đơn hàng vào giỏ hàng.")
    return redirect('myapp:view_cart')

@login_required
def book_table(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    ban_an_raw = BanAn.objects.all()
    ban_an = {
        'Ngoài Trời': {
            'Tầng 1': [],
            'Tầng 2': [],
        },
        'Trong Nhà': {
            'Tầng 1': [],
            'Tầng 2': [],
        },
    }
    for ban in ban_an_raw:
        vi_tri = ban.get_vi_tri_display()
        tang = ban.get_tang_display()
        ban_an[vi_tri][tang].append(ban)

    thuc_don = ThucDon.objects.filter(da_an=False)
    gio_hang = GioHang.objects.filter(nguoi_dung=request.user)
    tong_tien = sum(item.mon_an.gia_tien * item.so_luong for item in gio_hang)

    if request.method == 'POST':
        booking_type = request.POST.get('booking_type')
        ban_an_id = request.POST.get('ban_an')
        thoi_gian_dat = request.POST.get('thoi_gian_dat')
        so_nguoi = request.POST.get('so_nguoi')
        ten_khach_hang = request.POST.get('ten_khach_hang')
        so_dien_thoai_khach_hang = request.POST.get('so_dien_thoai_khach_hang')

        try:
            ban_an_selected = BanAn.objects.get(ma_ban=ban_an_id)
            if ban_an_selected.trang_thai != 'trong':
                messages.error(request, "Bàn đã có người, vui lòng chọn bàn khác.")
                return redirect('myapp:book_table')

            thoi_gian_dat = datetime.strptime(thoi_gian_dat, '%Y-%m-%dT%H:%M')
            if thoi_gian_dat < datetime.now():
                messages.error(request, "Thời gian đặt phải từ hiện tại trở đi.")
                return redirect('myapp:book_table')

            dat_ban_overlap = DatBan.objects.filter(
                ban_an=ban_an_selected,
                thoi_gian_dat__date=thoi_gian_dat.date(),
                thoi_gian_dat__hour=thoi_gian_dat.hour,
                trang_thai__in=['cho_xac_nhan', 'da_xac_nhan']
            )
            if dat_ban_overlap.exists():
                messages.error(request, "Bàn đã được đặt trong khoảng thời gian này, vui lòng chọn thời gian khác.")
                return redirect('myapp:book_table')

            so_nguoi = int(so_nguoi)
            if so_nguoi > ban_an_selected.suc_chua:
                messages.error(request, f"Bàn {ban_an_selected} chỉ chứa tối đa {ban_an_selected.suc_chua} người.")
                return redirect('myapp:book_table')

            if ban_an_selected.vi_tri == 'ngoai_troi' and (so_nguoi < 4 or so_nguoi > 5):
                messages.error(request, "Bàn ngoài trời chỉ dành cho 4-5 người.")
                return redirect('myapp:book_table')

            dat_ban = DatBan.objects.create(
                nguoi_dung=request.user,
                ban_an=ban_an_selected,
                thoi_gian_dat=thoi_gian_dat,
                so_nguoi=so_nguoi,
                ten_khach_hang=ten_khach_hang,
                so_dien_thoai_khach_hang=so_dien_thoai_khach_hang,
                trang_thai='cho_xac_nhan'
            )

            don_hang = None
            if booking_type == 'table_and_order':
                if not gio_hang.exists():
                    messages.error(request, "Giỏ hàng trống. Vui lòng chọn ít nhất một món để đặt bàn và đặt món.")
                    dat_ban.delete()
                    return redirect('myapp:book_table')

                don_hang = DonHang.objects.create(
                    nguoi_dung=request.user,
                    loai_don_hang='tai_quan',
                    trang_thai='da_xac_nhan',
                    thanh_toan='chua_thanh_toan',
                    so_dien_thoai=so_dien_thoai_khach_hang,
                    thoi_gian_dat=thoi_gian_dat,
                    tong_tien=tong_tien,
                    ngay_tao=now()
                )

                for item in gio_hang:
                    ChiTietDonHang.objects.create(
                        don_hang=don_hang,
                        mon_an=item.mon_an,
                        so_luong=item.so_luong,
                        gia_tien=item.mon_an.gia_tien
                    )

                dat_ban.don_hang = don_hang
                dat_ban.save()

                return redirect('myapp:payment', ma_dat_ban=dat_ban.ma_dat_ban)

            quan_ly_nhan_vien = NguoiDung.objects.filter(vai_tro__in=['quan_ly', 'nhan_vien'])
            for nguoi_nhan in quan_ly_nhan_vien:
                if not NguoiDung.objects.filter(pk=nguoi_nhan.pk).exists():
                    logger.warning(f"Skipping ThongBao for nguoi_nhan ID {nguoi_nhan.pk}: Does not exist")
                    continue
                ThongBao.objects.create(
                    don_hang=don_hang,
                    nguoi_nhan=nguoi_nhan,
                    noi_dung=f"Có đặt bàn mới #{dat_ban.ma_dat_ban} từ {request.user.username} vào {dat_ban.thoi_gian_dat}. " +
                             (f"Kèm đơn hàng #{don_hang.ma_don_hang}." if don_hang else "")
                )

            messages.success(request, "Đặt bàn thành công! Vui lòng chờ xác nhận.")
            return render(request, 'booking_success.html')

        except BanAn.DoesNotExist:
            messages.error(request, "Bàn không tồn tại.")
            return redirect('myapp:book_table')
        except ValueError as e:
            messages.error(request, "Thời gian đặt không hợp lệ.")
            return redirect('myapp:book_table')
        except Exception as e:
            logger.error(f"Error in book_table: {str(e)}", exc_info=True)
            messages.error(request, f"Lỗi khi đặt bàn: {str(e)}")
            return redirect('myapp:book_table')

    context = {
        'ban_an': ban_an,
        'thuc_don': thuc_don,
        'gio_hang': gio_hang,
        'tong_tien': tong_tien,
    }
    return render(request, 'book_table.html', context)

@login_required
def payment(request, ma_dat_ban):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    dat_ban = get_object_or_404(DatBan, ma_dat_ban=ma_dat_ban, nguoi_dung=request.user)
    if not dat_ban.don_hang:
        messages.error(request, "Không tìm thấy đơn hàng liên quan đến đặt bàn này.")
        return redirect('myapp:book_table')

    context = {
        'dat_ban': dat_ban,
        'don_hang': dat_ban.don_hang,
    }
    return render(request, 'payment.html', context)

@login_required
def process_payment(request, ma_dat_ban):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    if request.method == 'POST':
        dat_ban = get_object_or_404(DatBan, ma_dat_ban=ma_dat_ban, nguoi_dung=request.user)
        don_hang = dat_ban.don_hang

        if not don_hang:
            messages.error(request, "Không tìm thấy đơn hàng liên quan đến đặt bàn này.")
            return redirect('myapp:book_table')

        try:
            don_hang.thanh_toan = 'da_thanh_toan'
            don_hang.save()

            GioHang.objects.filter(nguoi_dung=request.user).delete()

            quan_ly_nhan_vien = NguoiDung.objects.filter(vai_tro__in=['quan_ly', 'nhan_vien'])
            for nguoi_nhan in quan_ly_nhan_vien:
                if not NguoiDung.objects.filter(pk=nguoi_nhan.pk).exists():
                    logger.warning(f"Skipping ThongBao for nguoi_nhan ID {nguoi_nhan.pk}: Does not exist")
                    continue
                ThongBao.objects.create(
                    don_hang=don_hang,
                    nguoi_nhan=nguoi_nhan,
                    noi_dung=f"Có đặt bàn mới #{dat_ban.ma_dat_ban} từ {request.user.username} vào {dat_ban.thoi_gian_dat}. " +
                             f"Kèm đơn hàng #{don_hang.ma_don_hang} (Đã thanh toán)."
                )

            messages.success(request,
                             f"Thanh toán thành công! Đặt bàn #{dat_ban.ma_dat_ban} và đơn hàng #{don_hang.ma_don_hang} đã được xác nhận.")
            return render(request, 'booking_success.html')

        except Exception as e:
            logger.error(f"Error in process_payment: {str(e)}", exc_info=True)
            messages.error(request, f"Lỗi khi xử lý thanh toán: {str(e)}")
            return redirect('myapp:book_table')

    return redirect('myapp:book_table')

@login_required
def booking_history(request):
    if request.user.vai_tro != 'khach_hang':
        messages.error(request, "Bạn không có quyền truy cập trang này. Vui lòng đăng nhập với tài khoản khách hàng.")
        return redirect('myapp:redirect_based_on_role')

    dat_ban_list = DatBan.objects.filter(nguoi_dung=request.user).order_by('-thoi_gian_dat')
    context = {
        'dat_ban_list': dat_ban_list,
    }
    return render(request, 'booking_history.html', context)

# View để hiển thị các đánh giá công khai
def public_reviews(request):
    danh_gia_list = DanhGia.objects.all().order_by('-ngay_danh_gia')
    don_hang_list = DonHang.objects.filter(danh_gia__isnull=False).distinct()

    # Xử lý logic lọc đánh giá ban đầu và bổ sung
    don_hang_data = []
    for don_hang in don_hang_list:
        danh_gia_ban_dau = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=True).first()
        danh_gia_bo_sung = DanhGia.objects.filter(don_hang=don_hang, la_danh_gia_ban_dau=False).first()
        don_hang_data.append({
            'don_hang': don_hang,
            'danh_gia_ban_dau': danh_gia_ban_dau,
            'danh_gia_bo_sung': danh_gia_bo_sung,
        })

    # Tính toán số lượng đánh giá cho từng mức sao (1-5 sao) và tỷ lệ phần trăm
    total_reviews = danh_gia_list.count()
    rating_counts = {}
    rating_percentages = {}
    for star in range(1, 6):
        count = danh_gia_list.filter(so_sao=star).count()
        rating_counts[star] = count
        percentage = (count / total_reviews * 100) if total_reviews > 0 else 0
        rating_percentages[star] = round(percentage, 1)

    context = {
        'danh_gia_list': danh_gia_list,
        'don_hang_data': don_hang_data,
        'total_reviews': total_reviews,
        'rating_counts': rating_counts,
        'rating_percentages': rating_percentages,
    }
    return render(request, 'public_reviews.html', context)

@login_required
def notifications(request):
    thong_bao_list = ThongBao.objects.filter(nguoi_nhan=request.user).order_by('-ngay_tao')
    thong_bao_list.update(da_xem=True)

    context = {
        'thong_bao_list': thong_bao_list,
    }
    return render(request, 'notifications.html', context)

@login_required
def get_unread_notifications_count(request):
    count = ThongBao.objects.filter(nguoi_nhan=request.user, da_xem=False).count()
    return JsonResponse({'count': count})