from django.contrib import admin
from .models import ThucDon, DonHang, ChiTietDonHang, GioHang, ThongBao, DanhGia, NguoiDung, MonYeuThich, BanAn, DatBan, MaGiamGia, PhienTroChuyen, TinNhan, BaoCaoDoanhThu
import logging

logger = logging.getLogger(__name__)

@admin.register(DonHang)
class DonHangAdmin(admin.ModelAdmin):
    list_display = ['ma_don_hang', 'nguoi_dung', 'loai_don_hang', 'trang_thai', 'thanh_toan', 'tong_tien', 'ngay_tao']
    list_filter = ['loai_don_hang', 'trang_thai', 'thanh_toan']
    search_fields = ['ma_don_hang', 'nguoi_dung__username']

    def save_model(self, request, obj, form, change):
        try:
            if not NguoiDung.objects.filter(pk=obj.nguoi_dung_id).exists():
                logger.error(f"IntegrityError: nguoi_dung with ID {obj.nguoi_dung_id} does not exist for DonHang {obj.ma_don_hang}")
                self.message_user(request, f"Không thể lưu đơn hàng: Người dùng với ID {obj.nguoi_dung_id} không tồn tại.", level='error')
                return

            chi_tiet_items = ChiTietDonHang.objects.filter(don_hang=obj)
            for item in chi_tiet_items:
                if not ThucDon.objects.filter(pk=item.mon_an_id).exists():
                    logger.error(f"IntegrityError: mon_an with ID {item.mon_an_id} does not exist for ChiTietDonHang of DonHang {obj.ma_don_hang}")
                    self.message_user(request, f"Không thể lưu đơn hàng: Món ăn với ID {item.mon_an_id} không tồn tại.", level='error')
                    return

            thong_bao_items = ThongBao.objects.filter(don_hang=obj)
            for thong_bao in thong_bao_items:
                if not NguoiDung.objects.filter(pk=thong_bao.nguoi_nhan_id).exists():
                    logger.error(f"IntegrityError: nguoi_nhan with ID {thong_bao.nguoi_nhan_id} does not exist for ThongBao of DonHang {obj.ma_don_hang}")
                    self.message_user(request, f"Không thể lưu đơn hàng: Người nhận thông báo với ID {thong_bao.nguoi_nhan_id} không tồn tại.", level='error')
                    return

            super().save_model(request, obj, form, change)
        except Exception as e:
            logger.error(f"Error saving DonHang {obj.ma_don_hang}: {str(e)}", exc_info=True)
            self.message_user(request, f"Không thể lưu đơn hàng: {str(e)}", level='error')

@admin.register(ThucDon)
class ThucDonAdmin(admin.ModelAdmin):
    list_display = ['ma_mon', 'ten_mon', 'gia_tien', 'danh_muc', 'da_an']
    list_filter = ['danh_muc', 'da_an']
    search_fields = ['ten_mon']

@admin.register(ChiTietDonHang)
class ChiTietDonHangAdmin(admin.ModelAdmin):
    list_display = ['don_hang', 'mon_an', 'so_luong', 'gia_tien']
    search_fields = ['don_hang__ma_don_hang', 'mon_an__ten_mon']

@admin.register(GioHang)
class GioHangAdmin(admin.ModelAdmin):
    list_display = ['nguoi_dung', 'mon_an', 'so_luong']
    search_fields = ['nguoi_dung__username', 'mon_an__ten_mon']

@admin.register(ThongBao)
class ThongBaoAdmin(admin.ModelAdmin):
    list_display = ['don_hang', 'nguoi_nhan', 'noi_dung', 'da_xem', 'ngay_tao']
    search_fields = ['don_hang__ma_don_hang', 'nguoi_nhan__username']
    list_filter = ['da_xem']

@admin.register(DanhGia)
class DanhGiaAdmin(admin.ModelAdmin):
    list_display = ['don_hang', 'so_sao', 'ngay_danh_gia']
    search_fields = ['don_hang__ma_don_hang']

@admin.register(NguoiDung)
class NguoiDungAdmin(admin.ModelAdmin):
    list_display = ['username', 'vai_tro', 'ho_ten']
    list_filter = ['vai_tro']
    search_fields = ['username', 'ho_ten']

@admin.register(MonYeuThich)
class MonYeuThichAdmin(admin.ModelAdmin):
    list_display = ['nguoi_dung', 'mon_an']
    search_fields = ['nguoi_dung__username', 'mon_an__ten_mon']

@admin.register(BanAn)
class BanAnAdmin(admin.ModelAdmin):
    list_display = ['so_ban', 'suc_chua', 'trang_thai']
    list_filter = ['trang_thai']
    search_fields = ['so_ban']

@admin.register(DatBan)
class DatBanAdmin(admin.ModelAdmin):
    list_display = ['ban_an', 'thoi_gian_dat', 'so_nguoi', 'trang_thai']
    list_filter = ['trang_thai']
    search_fields = ['nguoi_dung__username', 'ten_khach_hang']

@admin.register(MaGiamGia)
class MaGiamGiaAdmin(admin.ModelAdmin):
    list_display = ['ma_code', 'gia_tri', 'ngay_het_han']
    search_fields = ['ma_code']

@admin.register(PhienTroChuyen)
class PhienTroChuyenAdmin(admin.ModelAdmin):
    list_display = ['ma_phien', 'khach_hang', 'cua_hang', 'ngay_tao']
    search_fields = ['khach_hang__username', 'cua_hang__username']

@admin.register(TinNhan)
class TinNhanAdmin(admin.ModelAdmin):
    list_display = ['phien_tro_chuyen', 'nguoi_gui', 'thoi_gian_gui']
    search_fields = ['phien_tro_chuyen__ma_phien', 'nguoi_gui__username']

@admin.register(BaoCaoDoanhThu)
class BaoCaoDoanhThuAdmin(admin.ModelAdmin):
    list_display = ['ky_bao_cao', 'tong_doanh_thu', 'ngay_bat_dau', 'ngay_ket_thuc']
    list_filter = ['ky_bao_cao']