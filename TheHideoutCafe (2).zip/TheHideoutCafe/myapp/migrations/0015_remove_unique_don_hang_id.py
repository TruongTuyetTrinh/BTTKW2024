from django.db import migrations

def remove_unique_constraint(apps, schema_editor):
    # Tạo bảng mới không có ràng buộc UNIQUE
    schema_editor.execute("""
        CREATE TABLE myapp_danhgia_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            don_hang_id INTEGER NOT NULL,
            so_sao INTEGER NOT NULL,
            nhan_xet TEXT,
            hinh_anh TEXT,
            ngay_danh_gia DATETIME NOT NULL,
            phan_hoi TEXT,
            ngay_phan_hoi DATETIME,
            la_danh_gia_ban_dau BOOLEAN NOT NULL,
            FOREIGN KEY (don_hang_id) REFERENCES myapp_donhang (ma_don_hang) ON DELETE CASCADE
        );
    """)

    # Sao chép dữ liệu từ bảng cũ sang bảng mới
    schema_editor.execute("""
        INSERT INTO myapp_danhgia_new (
            id, don_hang_id, so_sao, nhan_xet, hinh_anh, ngay_danh_gia, phan_hoi, ngay_phan_hoi, la_danh_gia_ban_dau
        )
        SELECT id, don_hang_id, so_sao, nhan_xet, hinh_anh, ngay_danh_gia, phan_hoi, ngay_phan_hoi, la_danh_gia_ban_dau
        FROM myapp_danhgia;
    """)

    # Xóa bảng cũ
    schema_editor.execute("DROP TABLE myapp_danhgia;")

    # Đổi tên bảng mới thành tên bảng cũ
    schema_editor.execute("ALTER TABLE myapp_danhgia_new RENAME TO myapp_danhgia;")

def add_unique_constraint(apps, schema_editor):
    # Thêm lại ràng buộc UNIQUE nếu migration được rollback (không thực sự cần thiết, nhưng để hoàn chỉnh)
    schema_editor.execute("CREATE UNIQUE INDEX myapp_danhgia_don_hang_id_unique ON myapp_danhgia (don_hang_id);")

class Migration(migrations.Migration):

    dependencies = [
        ('myapp', '0014_danhgia_la_danh_gia_ban_dau'),
    ]

    operations = [
        migrations.RunPython(
            code=remove_unique_constraint,
            reverse_code=add_unique_constraint,
        ),
    ]