from django.urls import path
from . import views

app_name = 'myapp'

urlpatterns = [
    # Quản lý
    path('menu/quanly/', views.menu_management, name='menu_management'),
    path('menu/quanly/add/', views.add_menu_item, name='add_menu_item'),
    path('menu/quanly/edit/', views.edit_menu_item, name='edit_menu_item'),
    path('menu/quanly/toggle-visibility/', views.toggle_menu_item_visibility, name='toggle_menu_item_visibility'),
    path('orders/', views.order_list, name='order_list'),
    path('orders/create/', views.create_order, name='create_order'),
    path('orders/update_status/', views.update_order_status, name='update_order_status'),
    path('bookings/', views.manage_bookings, name='manage_bookings'),
    path('bookings/confirm/<int:ma_dat_ban>/', views.confirm_booking, name='confirm_booking'),
    path('bookings/cancel/<int:ma_dat_ban>/', views.cancel_booking, name='cancel_booking'),

    # Nhân viên
    path('menu/nhanvien/', views.menu_nhanvien, name='menu_nhanvien'),
    path('menu/nhanvien/edit/', views.edit_menu_item_nhanvien, name='edit_menu_item_nhanvien'),
    path('menu/nhanvien/toggle-visibility/', views.toggle_menu_item_visibility_nhanvien, name='toggle_menu_item_visibility_nhanvien'),
    path('bookings/', views.manage_bookings, name='manage_bookings'),
    path('bookings/confirm/<int:ma_dat_ban>/', views.confirm_booking, name='confirm_booking'),
    path('bookings/cancel/<int:ma_dat_ban>/', views.cancel_booking, name='cancel_booking'),

    # Khách hàng
    path('menu/khachhang/', views.menu_khachhang, name='menu_khachhang'),
    path('menu/khachhang/add-to-cart/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.view_cart, name='view_cart'),
    path('update-cart/', views.update_cart, name='update_cart'),
    path('place-order/', views.place_order, name='place_order'),
    path('order/<int:ma_don_hang>/', views.order_detail, name='order_detail'),
    path('order/<int:ma_don_hang>/rate/', views.rate_order, name='rate_order'),  # Thêm route cho đánh giá
    path('orders/khachhang/', views.order_history, name='order_history'),
    path('order/<int:ma_don_hang>/cancel/', views.cancel_order, name='cancel_order'),
    path('order/<int:ma_don_hang>/reorder/', views.reorder, name='reorder'),
    path('book-table/', views.book_table, name='book_table'),
    path('payment/<int:ma_dat_ban>/', views.payment, name='payment'),
    path('process-payment/<int:ma_dat_ban>/', views.process_payment, name='process_payment'),
    path('booking-history/', views.booking_history, name='booking_history'),
    path('reviews/', views.public_reviews, name='public_reviews'),
path('notifications/', views.notifications, name='notifications'),
path('get-unread-notifications-count/', views.get_unread_notifications_count, name='get_unread_notifications_count'),
    # Chuyển hướng
    path('menu/', views.redirect_based_on_role, name='redirect_based_on_role'),
]